#!/usr/bin/env bash

rm -rf build dist *.egg-info
find . -name '*.pyc' -delete
find . -name '*.log' -delete
